public class InSufficentAgeException extends RuntimeException {
public InSufficentAgeException() {
super("Age is not sufficient to vote....");
}
}